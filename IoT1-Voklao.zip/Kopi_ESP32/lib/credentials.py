credentials = {
    'ssid' : 'LTE-1824',
    'password' : 'Password1',
    'ADAFRUIT_IO_URL' : b'io.adafruit.com',
    'ADAFRUIT_USERNAME' : b'Shadow02Hunter',
    'ADAFRUIT_IO_KEY' : b'aio_pASe02kCLIJV6KBAfeyRPhEP1nF9',
    'ADAFRUIT_IO_FEEDNAME' : b'NeoPixel'
    }